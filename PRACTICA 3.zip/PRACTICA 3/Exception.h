//Ivan Artes Climent, Amadeo Barbera Simo

#include <stdexcept>

using std::runtime_error;

class  Exception: public runtime_error
{
	public:
		Exception()
			:runtime_error("Se ha producido un error"){};
};

class  PilaVacia: public runtime_error
{
	public:
		PilaVacia()
			:runtime_error("La pila esta vacia"){};
};



class  PilaLlena: public runtime_error
{
	public:
		PilaLlena()
			:runtime_error("La pila esta llena"){};
};
