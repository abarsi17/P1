#include <iostream>
#include "Pila.h"
#include "Exception.h"

using namespace std;

//Funciones recursivas
int altura (Pila);
int alturaDos (Pila &);
int multi (Pila &);
int imparMenosPar (Pila &);
Pila borrar (Pila, int );


int main ()
{
    int res;
    int MAX = 10;
    Pila  p(MAX);
    
    
    for (int i = 0; i < MAX; i++)
    {
        p.apilar (2);
    }
    
    p.mostrar();
    
    res = multi(p);
    
    cout << "resultado: " << res <<  "\naccesos: " <<  p.getAccesos() <<endl;
    
    return 0;
}


/*************************** altura (Pila p) **************************/ /**
 *
 *  Devuelve el n�mero de elementos en la pila
 *
 */ /**********************************************************************/
 int altura (Pila p)
 {
     int accesos;
     int num;
     
     if (p.vacia() )
     {
        num = 0;
        accesos = 1;
     }
     
     else
     {
         p.desapilar();
         num = altura (p) + 1;
     }
     
     accesos ++;
     p.setAccesos(accesos);
     return num;
 }
 
 /*************************** alturaDos(Pila & p) **************************/ /**
 *
 *  Devuelve el n�mero de elementos en la pila.
 *
 */ /**********************************************************************/
int alturaDos(Pila & p)
{
     int num;
     int accesos;
     
     if (p.vacia() )
     {
         num = 0;
         accesos = 1;
     }
     
     else
     {
         p.desapilar();
         num = alturaDos (p) + 1;
         accesos ++;
     }
     
     return num;
}

/*************************** multi (Pila & p) **************************/ /**
 *
 *  Devuelve la multiplicaci�n de todos los elementos de la pila
 *
 */ /**********************************************************************/
int multi (Pila & p)
 {
     int res;
     
     if (altura(p) == 1)
     {
         res = p.Cima();
     }
     
     else
     {
         res = p.Cima();
         p.desapilar();
         res = multi (p)*res;
     }
     
     return res;
 }

/*
int imparMenosPar (Pila & p)
{
    int res = 0;
   */ 





