#include <iostream>
#include "Pila.h"
#include "Exception.h"

using namespace std;

int main ()
{
	//creamos la pila con un maximo de 10 elementos
    Pila p(10);
    
    //ponemos el try catch donde creemos que podemos tener un error para que nos diga donde esta el error pero pueda seguir haciendo el programa
    try
    {
        p.desapilar();
    }
    catch(PilaVacia& e) 
    {
        cout << "error:" << e.what() << endl;
    }
    for(int i = 1; i <= 11; i++)
    {
        try
        {
            p.apilar(i);
        }
        catch(PilaLlena& e)
        {
            cout << "error:" << e.what() << endl;
        }
            
    }
    p.mostrar();
    cout << "Accesos realizados: " << p.getAccesos() << endl;
    
    return 0;
}
