/***************************** Pila.cpp *********************************/ /**
 *
 * @file Pila.cpp
 *
 * @brief Práctica de EDA 3.
 *
 * @version 1.4
 * @author Ivan Artes y Amadeo Barberá
 * @date 25/10/2019
 */ /**************************************************************************/

#include "Pila.h"
#include "Exception.h"

using namespace std;

/************************* Pila::Pila (int m) ******************************/ /**
 *
 * Es el constructor de la clase 
 * 
 */ /**********************************************************************/
Pila::Pila (int m)
{
    MAX = m;
    cima = -1;
    accesos = 0;
    v = new int [m];
}

/*************************** Pila:: Pila (const Pila & p) **************************/ /**
 *
 * 
 *
 */ /**********************************************************************/
/*
 Pila:: Pila (const Pila & p)
 {
     Pila q (MAX) , h (MAX);
     
     for (int i = 0; i < MAX -1; i++)
     {
         q.apilar (p.cima ());
         p.desapilar ();
     }
     
        for (int j = 0; j < MAX -1; j++)
     {
         h.apilar (q.cima ());
         q.desapilar ();
     }
     
     return ;
 }
     
*/
/*************************** Pila::apilar (int x) **************************/ /**
 *
 *  Apila un entero
 *
 */ /**********************************************************************/
void Pila::apilar (int x)
{
   if (cima != MAX-1)
   {
      cima++; 
      v[cima] = x; 
   }
   
   else
       throw PilaLlena();
   
   accesos ++;
   return;
}

/**************************** Pila::vacia () *************************/ /**
 *
 *  Indica si la pila esta vacia
 *
 */ /**********************************************************************/
bool Pila::vacia ()
{
    bool ok  = false;
    
    if (cima == -1)
    {
        //throw PilaVacia();
        ok = true;
    }
        
    
	return ok;
}

/****************************** Pila::desapilar () ************************/ /**
 *
 *  Desapila la cima
 *
 */ /**********************************************************************/
void Pila::desapilar ()
{
    
    if (cima != -1)
           cima --;
    
    else
        throw PilaVacia();
    
    accesos ++;
       return;
}

/**************************** Pila::Cima() ***********************/ /**
 *
 *  Devuelve el elemento que se encuentra en la cima de la pila.
 *
 */ /**********************************************************************/
int Pila::Cima()
{
    int x = 0;
    
	if (cima != -1)
        x = v[cima];
    
    accesos ++;
    
	return x; 
}

/************************ Pila::getAccesos () ***************************/ /**
 *
 *  Devuelve el n�mero de accesos realizados a la pila
 *
 */ /**********************************************************************/
int Pila::getAccesos ()
{
	return accesos;
}

/************************* Pila::resetAccesos () *************************/ /**
 *
 *  Pone a cero el n�mero de accesos.
 *
 */ /**********************************************************************/
void Pila::resetAccesos ()
{
	accesos = 0;
	
	return;
}

/**************************** Pila::mostrar() **********************/ /**
 *
 *  Muestra la pila
 *
 */ /**********************************************************************/
void Pila::mostrar()
{
    for (int i = 0; i < MAX; i++)
    {
        cout << "Elemento " << i << ": " << v[i] << endl;
    }
	return;
}

/************************ Pila::getAccesos () ***************************/ /**
 *
 *  Modifica el valor de la variable accesos
 *
 */ /**********************************************************************/
void Pila :: setAccesos (int a)
{
    accesos = a;
}

 
 
 
 
 
 

