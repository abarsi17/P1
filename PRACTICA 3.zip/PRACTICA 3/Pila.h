#ifndef _PILA_H_
#define _PILA_H_
#include <iostream>

class Pila 
{
public:
    Pila (int);
    //Pila (const Pila&);
    //~Pila();
    void apilar (int);
    void desapilar();
    int Cima ();
    bool vacia ();
    int getAccesos();
    void setAccesos(int );
    void resetAccesos();
    void mostrar ();
    
    
private:
    int MAX;
    int *v;
    int accesos;
    int cima;
};

#endif
